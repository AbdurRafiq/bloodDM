# Django blood bank management system
"# BloodBankManagementUsingDjango" 
