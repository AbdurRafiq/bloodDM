from django.contrib import admin
from .models import SearchLogo


admin.site.register(SearchLogo)
